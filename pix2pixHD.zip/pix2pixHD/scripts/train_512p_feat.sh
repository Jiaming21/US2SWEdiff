### Adding instances and encoded features
python train.py --name label2city_512p_feat --instance_feat