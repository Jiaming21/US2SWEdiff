### Using labels only
python train.py --name label2city_512p